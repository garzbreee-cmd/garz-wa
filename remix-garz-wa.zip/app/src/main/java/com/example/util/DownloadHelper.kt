package com.example.util

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.widget.Toast

class DownloadHelper(private val context: Context) {

  private val downloadManager = 
    context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

  fun handleDownload(
    url: String,
    userAgent: String?,
    contentDisposition: String?,
    mimeType: String?
  ) {
    try {
      if (url.startsWith("data:") || url.startsWith("blob:")) {
        Toast.makeText(
          context,
          "Mempersiapkan unduhan berkas...",
          Toast.LENGTH_SHORT
        ).show()
        return
      }

      val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
      val uri = Uri.parse(url)

      val request = DownloadManager.Request(uri).apply {
        setMimeType(mimeType)
        val cookies = CookieManager.getInstance().getCookie(url)
        if (!cookies.isNullOrEmpty()) {
          addRequestHeader("cookie", cookies)
        }
        if (!userAgent.isNullOrEmpty()) {
          addRequestHeader("User-Agent", userAgent)
        }
        setDescription("Mengunduh berkas dari WhatsApp Web: $fileName")
        setTitle(fileName)
        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
      }

      downloadManager.enqueue(request)
      Toast.makeText(
        context,
        "Mengunduh ke folder Downloads: $fileName",
        Toast.LENGTH_SHORT
      ).show()
    } catch (e: Exception) {
      Toast.makeText(
        context,
        "Gagal mengunduh: ${e.localizedMessage ?: "Terjadi kesalahan"}",
        Toast.LENGTH_LONG
      ).show()
    }
  }
}
