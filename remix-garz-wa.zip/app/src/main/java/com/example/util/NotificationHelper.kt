package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import java.util.concurrent.atomic.AtomicInteger

class NotificationHelper(private val context: Context) {

  private val notificationManager = 
    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  private val idGenerator = AtomicInteger(1000)

  init {
    createNotificationChannel()
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        WebConstants.NOTIFICATION_CHANNEL_ID,
        WebConstants.NOTIFICATION_CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = WebConstants.NOTIFICATION_CHANNEL_DESC
        enableVibration(true)
        enableLights(true)
        setShowBadge(true)
      }
      notificationManager.createNotificationChannel(channel)
    }
  }

  fun hasNotificationPermission(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      ContextCompat.checkSelfPermission(
        context,
        android.Manifest.permission.POST_NOTIFICATIONS
      ) == PackageManager.PERMISSION_GRANTED
    } else {
      true
    }
  }

  fun showNotification(title: String, body: String, tag: String? = null) {
    if (!hasNotificationPermission()) return

    val cleanTitle = title.ifBlank { "WhatsApp Web" }
    val cleanBody = body.ifBlank { "Pesan baru diterima" }

    val intent = Intent(context, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }

    val pendingIntent = PendingIntent.getActivity(
      context,
      0,
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val notification = NotificationCompat.Builder(context, WebConstants.NOTIFICATION_CHANNEL_ID)
      .setSmallIcon(R.drawable.ic_launcher_foreground)
      .setContentTitle(cleanTitle)
      .setContentText(cleanBody)
      .setStyle(NotificationCompat.BigTextStyle().bigText(cleanBody))
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setCategory(NotificationCompat.CATEGORY_MESSAGE)
      .setAutoCancel(true)
      .setContentIntent(pendingIntent)
      .setVibrate(longArrayOf(0, 250, 100, 250))
      .build()

    val notificationId = tag?.hashCode() ?: idGenerator.incrementAndGet()
    notificationManager.notify(notificationId, notification)
  }
}
