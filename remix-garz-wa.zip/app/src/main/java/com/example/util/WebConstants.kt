package com.example.util

object WebConstants {
  const val WHATSAPP_WEB_URL = "https://web.whatsapp.com/"
  
  // High-compatibility desktop Chrome User-Agent so WhatsApp Web loads the desktop QR interface
  const val DESKTOP_USER_AGENT = 
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

  const val MAC_USER_AGENT = 
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

  const val NOTIFICATION_CHANNEL_ID = "garz_wa_notifications"
  const val NOTIFICATION_CHANNEL_NAME = "Garz WA Pesan"
  const val NOTIFICATION_CHANNEL_DESC = "Notifikasi pesan masuk dan panggilan dari WhatsApp Web"

  // JavaScript bridge to intercept HTML5 Notification API in WhatsApp Web
  const val NOTIFICATION_INJECTION_SCRIPT = """
    (function() {
      if (window._garzWaInjected) return;
      window._garzWaInjected = true;
      
      try {
        const OriginalNotification = window.Notification;
        
        function CustomNotification(title, options) {
          options = options || {};
          const body = options.body || '';
          const tag = options.tag || '';
          const icon = options.icon || '';
          
          if (window.GarzBridge && window.GarzBridge.postWebNotification) {
            window.GarzBridge.postWebNotification(title, body, tag);
          }
          
          this.title = title;
          this.body = body;
          this.tag = tag;
          this.icon = icon;
          this.close = function() {};
          this.addEventListener = function(event, callback) {};
          this.removeEventListener = function(event, callback) {};
        }

        CustomNotification.permission = "granted";
        CustomNotification.requestPermission = function(callback) {
          if (typeof callback === 'function') {
            callback("granted");
          }
          return Promise.resolve("granted");
        };

        window.Notification = CustomNotification;
        console.log("[Garz WA] Notification bridge successfully injected.");
      } catch (e) {
        console.error("[Garz WA] Notification injection error:", e);
      }
    })();
  """
}
