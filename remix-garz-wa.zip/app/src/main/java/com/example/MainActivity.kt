package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.example.ui.GarzWaScreen
import com.example.ui.GarzWaViewModel
import com.example.ui.theme.GarzWATheme

class MainActivity : ComponentActivity() {

  private val viewModel: GarzWaViewModel by viewModels()

  private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
  private var pendingMediaPermissionRequest: PermissionRequest? = null

  // File Chooser launcher for uploading attachments / media / documents
  private val fileChooserLauncher = registerForActivityResult(
    ActivityResultContracts.StartActivityForResult()
  ) { result ->
    val callback = fileUploadCallback ?: return@registerForActivityResult
    if (result.resultCode == RESULT_OK) {
      val intentData = result.data
      val uris = when {
        intentData?.clipData != null -> {
          val clipData = intentData.clipData!!
          Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
        }
        intentData?.data != null -> {
          arrayOf(intentData.data!!)
        }
        else -> null
      }
      callback.onReceiveValue(uris)
    } else {
      callback.onReceiveValue(null)
    }
    fileUploadCallback = null
  }

  // Permission launcher for WebRTC media requests (Camera & Microphone)
  private val mediaPermissionsLauncher = registerForActivityResult(
    ActivityResultContracts.RequestMultiplePermissions()
  ) { permissions ->
    val request = pendingMediaPermissionRequest
    if (request != null) {
      val resourcesToGrant = mutableListOf<String>()
      for (res in request.resources) {
        when (res) {
          PermissionRequest.RESOURCE_AUDIO_CAPTURE -> {
            if (permissions[Manifest.permission.RECORD_AUDIO] == true ||
              ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            ) {
              resourcesToGrant.add(res)
            }
          }
          PermissionRequest.RESOURCE_VIDEO_CAPTURE -> {
            if (permissions[Manifest.permission.CAMERA] == true ||
              ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            ) {
              resourcesToGrant.add(res)
            }
          }
        }
      }

      if (resourcesToGrant.isNotEmpty()) {
        request.grant(resourcesToGrant.toTypedArray())
      } else {
        request.deny()
      }
      pendingMediaPermissionRequest = null
    }
  }

  // Permission launcher for Android 13+ push/web notifications
  private val notificationPermissionLauncher = registerForActivityResult(
    ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    viewModel.setNotificationPermission(isGranted)
    if (isGranted) {
      Toast.makeText(this, "Izin notifikasi WhatsApp aktif", Toast.LENGTH_SHORT).show()
    }
  }

  // General permission launcher for all device capabilities
  private val allPermissionsLauncher = registerForActivityResult(
    ActivityResultContracts.RequestMultiplePermissions()
  ) { permissions ->
    val notifGranted = permissions[Manifest.permission.POST_NOTIFICATIONS] ?: false
    viewModel.setNotificationPermission(notifGranted)
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Request notification permission automatically on startup for Android 13+
    requestInitialNotificationPermission()

    setContent {
      GarzWATheme {
        GarzWaScreen(
          viewModel = viewModel,
          onOpenFileChooser = { callback, params ->
            handleOpenFileChooser(callback, params)
          },
          onRequestMediaPermissions = { request ->
            handleMediaPermissionRequest(request)
          },
          onRequestNotificationPermission = {
            requestNotificationPermission()
          },
          onRequestAllDevicePermissions = {
            requestAllPermissions()
          }
        )
      }
    }
  }

  private fun requestInitialNotificationPermission() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val hasPermission = ContextCompat.checkSelfPermission(
        this,
        Manifest.permission.POST_NOTIFICATIONS
      ) == PackageManager.PERMISSION_GRANTED

      viewModel.setNotificationPermission(hasPermission)
      if (!hasPermission) {
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
      }
    } else {
      viewModel.setNotificationPermission(true)
    }
  }

  private fun requestNotificationPermission() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    } else {
      viewModel.setNotificationPermission(true)
      Toast.makeText(this, "Notifikasi aktif pada versi Android ini", Toast.LENGTH_SHORT).show()
    }
  }

  private fun requestAllPermissions() {
    val permissionsToRequest = mutableListOf<String>()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
    }
    permissionsToRequest.add(Manifest.permission.CAMERA)
    permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)

    allPermissionsLauncher.launch(permissionsToRequest.toTypedArray())
  }

  private fun handleOpenFileChooser(
    callback: ValueCallback<Array<Uri>>?,
    params: FileChooserParams?
  ): Boolean {
    // If a previous callback is still pending, cancel it
    fileUploadCallback?.onReceiveValue(null)
    fileUploadCallback = callback

    return try {
      val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
        addCategory(Intent.CATEGORY_OPENABLE)
        type = "*/*"
        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
      }
      fileChooserLauncher.launch(intent)
      true
    } catch (e: Exception) {
      // Fallback intent if default params intent fails
      try {
        val fallbackIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
          addCategory(Intent.CATEGORY_OPENABLE)
          type = "*/*"
          putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        fileChooserLauncher.launch(fallbackIntent)
        true
      } catch (ex: Exception) {
        fileUploadCallback?.onReceiveValue(null)
        fileUploadCallback = null
        Toast.makeText(this, "Tidak dapat membuka pemilih berkas", Toast.LENGTH_SHORT).show()
        false
      }
    }
  }

  private fun handleMediaPermissionRequest(request: PermissionRequest) {
    val neededPermissions = mutableListOf<String>()

    for (res in request.resources) {
      if (res == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
          neededPermissions.add(Manifest.permission.RECORD_AUDIO)
        }
      } else if (res == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
          neededPermissions.add(Manifest.permission.CAMERA)
        }
      }
    }

    if (neededPermissions.isEmpty()) {
      request.grant(request.resources)
    } else {
      pendingMediaPermissionRequest = request
      mediaPermissionsLauncher.launch(neededPermissions.toTypedArray())
    }
  }
}
