package com.example.ui

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class GarzWaUiState(
  val currentUrl: String = "https://web.whatsapp.com/",
  val loadingProgress: Int = 0,
  val isLoading: Boolean = true,
  val hasError: Boolean = false,
  val errorMessage: String? = null,
  val canGoBack: Boolean = false,
  val canGoForward: Boolean = false,
  val zoomLevel: Int = 100,
  val showAboutDialog: Boolean = false,
  val showLogoutDialog: Boolean = false,
  val showZoomDialog: Boolean = false,
  val showPermissionDialog: Boolean = false,
  val hasNotificationPermission: Boolean = false,
  val lastNotificationTitle: String? = null
)

class GarzWaViewModel : ViewModel() {

  private val _uiState = MutableStateFlow(GarzWaUiState())
  val uiState: StateFlow<GarzWaUiState> = _uiState.asStateFlow()

  fun updateLoadingProgress(progress: Int) {
    _uiState.update { 
      it.copy(
        loadingProgress = progress,
        isLoading = progress in 1..99
      ) 
    }
  }

  fun updatePageLoading(isLoading: Boolean, url: String?) {
    _uiState.update { 
      it.copy(
        isLoading = isLoading,
        currentUrl = url ?: it.currentUrl
      ) 
    }
  }

  fun updateErrorState(hasError: Boolean, message: String?) {
    _uiState.update { 
      it.copy(
        hasError = hasError,
        errorMessage = message
      ) 
    }
  }

  fun updateNavigationState(canGoBack: Boolean, canGoForward: Boolean) {
    _uiState.update { 
      it.copy(
        canGoBack = canGoBack,
        canGoForward = canGoForward
      ) 
    }
  }

  fun setZoomLevel(zoom: Int) {
    _uiState.update { it.copy(zoomLevel = zoom) }
  }

  fun setAboutDialogVisible(visible: Boolean) {
    _uiState.update { it.copy(showAboutDialog = visible) }
  }

  fun setLogoutDialogVisible(visible: Boolean) {
    _uiState.update { it.copy(showLogoutDialog = visible) }
  }

  fun setZoomDialogVisible(visible: Boolean) {
    _uiState.update { it.copy(showZoomDialog = visible) }
  }

  fun setPermissionDialogVisible(visible: Boolean) {
    _uiState.update { it.copy(showPermissionDialog = visible) }
  }

  fun setNotificationPermission(granted: Boolean) {
    _uiState.update { it.copy(hasNotificationPermission = granted) }
  }

  fun setLastNotification(title: String) {
    _uiState.update { it.copy(lastNotificationTitle = title) }
  }
}
