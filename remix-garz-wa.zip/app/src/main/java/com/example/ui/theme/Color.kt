package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// WhatsApp Dark Green Design System
val WaDarkBackground = Color(0xFF0B141A)
val WaDarkSurface = Color(0xFF111B21)
val WaDarkSurfaceVariant = Color(0xFF202C33)
val WaDarkSurfaceHighlight = Color(0xFF2A3942)

val WaGreenPrimary = Color(0xFF00A884)
val WaGreenAccent = Color(0xFF25D366)
val WaGreenDark = Color(0xFF005C4B)

val WaTextPrimary = Color(0xFFE9EDEF)
val WaTextSecondary = Color(0xFF8696A0)
val WaTextMuted = Color(0xFF667781)

val WaDivider = Color(0xFF222D34)
val WaBlueAccent = Color(0xFF53BDEB)
val WaError = Color(0xFFEA0038)
