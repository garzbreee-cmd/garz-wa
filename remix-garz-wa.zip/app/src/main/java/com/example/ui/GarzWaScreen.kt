package com.example.ui

import android.app.Activity
import android.net.Uri
import android.os.Build
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.theme.WaDarkBackground
import com.example.ui.theme.WaDarkSurface
import com.example.ui.theme.WaDarkSurfaceHighlight
import com.example.ui.theme.WaDarkSurfaceVariant
import com.example.ui.theme.WaDivider
import com.example.ui.theme.WaGreenAccent
import com.example.ui.theme.WaGreenDark
import com.example.ui.theme.WaGreenPrimary
import com.example.ui.theme.WaTextMuted
import com.example.ui.theme.WaTextPrimary
import com.example.ui.theme.WaTextSecondary
import com.example.util.DownloadHelper
import com.example.util.NotificationHelper
import com.example.util.WebConstants
import com.example.web.GarzNotificationBridge
import com.example.web.GarzWebChromeClient
import com.example.web.GarzWebViewClient

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GarzWaScreen(
  viewModel: GarzWaViewModel,
  onOpenFileChooser: (ValueCallback<Array<Uri>>?, FileChooserParams?) -> Boolean,
  onRequestMediaPermissions: (PermissionRequest) -> Unit,
  onRequestNotificationPermission: () -> Unit,
  onRequestAllDevicePermissions: () -> Unit
) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  var webViewInstance by remember { mutableStateOf<WebView?>(null) }
  var showOverflowMenu by remember { mutableStateOf(false) }

  val notificationHelper = remember { NotificationHelper(context) }
  val downloadHelper = remember { DownloadHelper(context) }

  // Check notification permission state initially
  LaunchedEffect(Unit) {
    viewModel.setNotificationPermission(notificationHelper.hasNotificationPermission())
  }

  // Handle hardware / gesture back button
  BackHandler(enabled = uiState.canGoBack) {
    webViewInstance?.let {
      if (it.canGoBack()) {
        it.goBack()
      }
    }
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .testTag("garz_wa_scaffold"),
    containerColor = WaDarkBackground,
    topBar = {
      Column(modifier = Modifier.fillMaxWidth()) {
        TopAppBar(
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = WaDarkSurface,
            titleContentColor = WaTextPrimary,
            actionIconContentColor = WaTextSecondary
          ),
          title = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.testTag("app_title_row")
            ) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(WaGreenDark),
                contentAlignment = Alignment.Center
              ) {
                Image(
                  painter = painterResource(id = R.drawable.garz_wa_icon),
                  contentDescription = "Logo Garz WA",
                  modifier = Modifier.size(28.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "Garz WA",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = WaTextPrimary
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  // Connection dot indicator
                  Box(
                    modifier = Modifier
                      .size(8.dp)
                      .clip(CircleShape)
                      .background(
                        when {
                          uiState.hasError -> Color(0xFFEA0038)
                          uiState.isLoading -> Color(0xFFF5A623)
                          else -> WaGreenAccent
                        }
                      )
                  )
                }
                Text(
                  text = if (uiState.isLoading) "Memuat WhatsApp..." else "WhatsApp Web Desktop",
                  fontSize = 11.sp,
                  color = WaTextMuted,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }
            }
          },
          actions = {
            // Back button
            IconButton(
              onClick = { webViewInstance?.goBack() },
              enabled = uiState.canGoBack,
              modifier = Modifier.testTag("back_nav_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Kembali ke Halaman Sebelumnya",
                tint = if (uiState.canGoBack) WaTextPrimary else WaTextMuted.copy(alpha = 0.4f)
              )
            }

            // Forward button
            IconButton(
              onClick = { webViewInstance?.goForward() },
              enabled = uiState.canGoForward,
              modifier = Modifier.testTag("forward_nav_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Maju ke Halaman Berikutnya",
                tint = if (uiState.canGoForward) WaTextPrimary else WaTextMuted.copy(alpha = 0.4f)
              )
            }

            // Refresh button
            IconButton(
              onClick = {
                viewModel.updateErrorState(false, null)
                webViewInstance?.reload()
              },
              modifier = Modifier.testTag("refresh_button")
            ) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Muat Ulang Halaman",
                tint = WaGreenAccent
              )
            }

            // Zoom level selector button
            IconButton(
              onClick = { viewModel.setZoomDialogVisible(true) },
              modifier = Modifier.testTag("zoom_button")
            ) {
              Icon(
                imageVector = Icons.Default.ZoomIn,
                contentDescription = "Pengaturan Ukuran Zoom Tampilan",
                tint = WaTextSecondary
              )
            }

            // Overflow menu button
            Box {
              IconButton(
                onClick = { showOverflowMenu = true },
                modifier = Modifier.testTag("overflow_menu_button")
              ) {
                Icon(
                  imageVector = Icons.Default.MoreVert,
                  contentDescription = "Menu Pilihan Tambahan",
                  tint = WaTextSecondary
                )
              }

              DropdownMenu(
                expanded = showOverflowMenu,
                onDismissRequest = { showOverflowMenu = false },
                modifier = Modifier
                  .background(WaDarkSurfaceVariant)
                  .border(1.dp, WaDivider, RoundedCornerShape(8.dp))
              ) {
                DropdownMenuItem(
                  text = {
                    Text(
                      text = "Buka WhatsApp Web Baru",
                      color = WaTextPrimary,
                      fontSize = 14.sp
                    )
                  },
                  onClick = {
                    showOverflowMenu = false
                    webViewInstance?.loadUrl(WebConstants.WHATSAPP_WEB_URL)
                  }
                )
                DropdownMenuItem(
                  text = {
                    Text(
                      text = "Pengaturan Izin & Notifikasi",
                      color = WaTextPrimary,
                      fontSize = 14.sp
                    )
                  },
                  onClick = {
                    showOverflowMenu = false
                    viewModel.setPermissionDialogVisible(true)
                  }
                )
                DropdownMenuItem(
                  text = {
                    Text(
                      text = "Info Keamanan & Multi-Akun",
                      color = WaTextPrimary,
                      fontSize = 14.sp
                    )
                  },
                  onClick = {
                    showOverflowMenu = false
                    viewModel.setAboutDialogVisible(true)
                  }
                )
                HorizontalDivider(color = WaDivider)
                DropdownMenuItem(
                  text = {
                    Text(
                      text = "Hapus Sesi & Keluar (Logout)",
                      color = Color(0xFFFF6B6B),
                      fontSize = 14.sp,
                      fontWeight = FontWeight.Medium
                    )
                  },
                  onClick = {
                    showOverflowMenu = false
                    viewModel.setLogoutDialogVisible(true)
                  }
                )
              }
            }
          }
        )

        // Loading bar
        AnimatedVisibility(
          visible = uiState.isLoading,
          enter = fadeIn(),
          exit = fadeOut()
        ) {
          LinearProgressIndicator(
            progress = { (uiState.loadingProgress / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
              .fillMaxWidth()
              .height(3.dp),
            color = WaGreenPrimary,
            trackColor = WaDarkSurfaceHighlight
          )
        }
      }
    }
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(WaDarkBackground)
    ) {
      // WebView Core
      AndroidView(
        modifier = Modifier
          .fillMaxSize()
          .testTag("whatsapp_webview"),
        factory = { ctx ->
          WebView(ctx).apply {
            layoutParams = ViewGroup.LayoutParams(
              ViewGroup.LayoutParams.MATCH_PARENT,
              ViewGroup.LayoutParams.MATCH_PARENT
            )

            // WebSettings configuration
            settings.apply {
              javaScriptEnabled = true
              domStorageEnabled = true
              databaseEnabled = true
              allowFileAccess = true
              allowContentAccess = true
              loadWithOverviewMode = true
              useWideViewPort = true
              builtInZoomControls = true
              displayZoomControls = false
              mediaPlaybackRequiresUserGesture = false
              cacheMode = WebSettings.LOAD_DEFAULT
              userAgentString = WebConstants.DESKTOP_USER_AGENT
              textZoom = uiState.zoomLevel
            }

            // Cookie and session storage configuration
            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            cookieManager.setAcceptThirdPartyCookies(this, true)

            // File download handler
            setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
              downloadHelper.handleDownload(url, userAgent, contentDisposition, mimetype)
            }

            // Notification JS interface bridge
            val notificationBridge = GarzNotificationBridge(
              notificationHelper = notificationHelper,
              onNotificationReceived = { title, _ ->
                viewModel.setLastNotification(title)
              }
            )
            addJavascriptInterface(notificationBridge, "GarzBridge")

            // WebChromeClient
            webChromeClient = GarzWebChromeClient(
              onProgressChanged = { progress ->
                viewModel.updateLoadingProgress(progress)
              },
              onOpenFileChooser = { callback, params ->
                onOpenFileChooser(callback, params)
              },
              onMediaPermissionRequest = { request ->
                onRequestMediaPermissions(request)
              }
            )

            // WebViewClient
            webViewClient = GarzWebViewClient(
              context = ctx,
              onPageLoadingStateChanged = { loading, url ->
                viewModel.updatePageLoading(loading, url)
              },
              onPageError = { error, message ->
                viewModel.updateErrorState(error, message)
              },
              onNavigationStateChanged = { back, forward ->
                viewModel.updateNavigationState(back, forward)
              }
            )

            // Initial URL load
            loadUrl(WebConstants.WHATSAPP_WEB_URL)
            webViewInstance = this
          }
        },
        update = { webView ->
          webView.settings.textZoom = uiState.zoomLevel
        }
      )

      // Offline / Error Overlay Banner
      if (uiState.hasError) {
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .align(Alignment.TopCenter),
          shape = RoundedCornerShape(12.dp),
          color = WaDarkSurfaceVariant,
          tonalElevation = 6.dp,
          shadowElevation = 8.dp
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Peringatan Koneksi",
                tint = Color(0xFFF5A623),
                modifier = Modifier.size(24.dp)
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Gagal Terhubung ke WhatsApp Web",
                  fontWeight = FontWeight.SemiBold,
                  color = WaTextPrimary,
                  fontSize = 14.sp
                )
                Text(
                  text = uiState.errorMessage ?: "Periksa koneksi internet Anda dan coba muat ulang.",
                  color = WaTextSecondary,
                  fontSize = 12.sp
                )
              }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
              onClick = {
                viewModel.updateErrorState(false, null)
                webViewInstance?.reload()
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = WaGreenPrimary,
                contentColor = Color.White
              ),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text("Coba Muat Ulang Sekarang")
            }
          }
        }
      }
    }
  }

  // --- DIALOGS ---

  // 1. About, Security & Multi-Account Limitation Dialog
  if (uiState.showAboutDialog) {
    AlertDialog(
      onDismissRequest = { viewModel.setAboutDialogVisible(false) },
      containerColor = WaDarkSurface,
      titleContentColor = WaTextPrimary,
      textContentColor = WaTextSecondary,
      icon = {
        Icon(
          imageVector = Icons.Default.Lock,
          contentDescription = null,
          tint = WaGreenAccent,
          modifier = Modifier.size(32.dp)
        )
      },
      title = {
        Text(
          text = "Keamanan & Batasan Multi-Akun",
          fontWeight = FontWeight.Bold,
          fontSize = 18.sp
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "• Klien Asli Terenkripsi:",
            fontWeight = FontWeight.Bold,
            color = WaGreenAccent,
            fontSize = 13.sp
          )
          Text(
            text = "Garz WA memuat WhatsApp Web resmi (https://web.whatsapp.com) secara langsung. Semua komunikasi terenkripsi end-to-end tanpa perantara server pihak ketiga.",
            fontSize = 13.sp,
            color = WaTextSecondary
          )

          Text(
            text = "• Privasi & Bebas Tiruan:",
            fontWeight = FontWeight.Bold,
            color = WaGreenAccent,
            fontSize = 13.sp
          )
          Text(
            text = "Aplikasi ini tidak pernah mengambil, menyalin, atau menyimpan kredensial atau nomor telepon di luar sandbox WebView Chromium bawaan Android.",
            fontSize = 13.sp,
            color = WaTextSecondary
          )

          Text(
            text = "• Batasan Multi-Akun (Penting):",
            fontWeight = FontWeight.Bold,
            color = Color(0xFFF5A623),
            fontSize = 13.sp
          )
          Text(
            text = "Multi-akun bersamaan TIDAK didukung pada versi ini karena arsitektur satu sesi per browser profil WhatsApp Web. Menjalankan beberapa akun sekaligus dalam satu sandbox dapat merusak kunci sesi enkripsi. Untuk berganti akun, gunakan fitur 'Hapus Sesi & Keluar'.",
            fontSize = 13.sp,
            color = WaTextSecondary
          )
        }
      },
      confirmButton = {
        Button(
          onClick = { viewModel.setAboutDialogVisible(false) },
          colors = ButtonDefaults.buttonColors(containerColor = WaGreenPrimary)
        ) {
          Text("Mengerti")
        }
      }
    )
  }

  // 2. Logout / Reset Session Confirmation Dialog
  if (uiState.showLogoutDialog) {
    AlertDialog(
      onDismissRequest = { viewModel.setLogoutDialogVisible(false) },
      containerColor = WaDarkSurface,
      titleContentColor = WaTextPrimary,
      textContentColor = WaTextSecondary,
      icon = {
        Icon(
          imageVector = Icons.Default.Warning,
          contentDescription = null,
          tint = Color(0xFFFF6B6B),
          modifier = Modifier.size(32.dp)
        )
      },
      title = {
        Text(
          text = "Hapus Sesi & Keluar?",
          fontWeight = FontWeight.Bold,
          fontSize = 18.sp
        )
      },
      text = {
        Text(
          text = "Seluruh cookie dan sesi login WhatsApp Web di WebView akan dibersihkan. Anda harus memindai kode QR ulang dari ponsel utama untuk masuk kembali.",
          fontSize = 13.sp,
          color = WaTextSecondary
        )
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.setLogoutDialogVisible(false)
            // Perform clean session logout
            CookieManager.getInstance().apply {
              removeAllCookies(null)
              flush()
            }
            WebStorage.getInstance().deleteAllData()
            webViewInstance?.apply {
              clearCache(true)
              clearFormData()
              clearHistory()
              loadUrl(WebConstants.WHATSAPP_WEB_URL)
            }
            Toast.makeText(context, "Sesi WhatsApp berhasil dibersihkan", Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA0038))
        ) {
          Text("Hapus Sesi", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { viewModel.setLogoutDialogVisible(false) }) {
          Text("Batal", color = WaTextSecondary)
        }
      }
    )
  }

  // 3. Zoom Control Dialog
  if (uiState.showZoomDialog) {
    val zoomOptions = listOf(80, 90, 100, 110, 125, 140)
    AlertDialog(
      onDismissRequest = { viewModel.setZoomDialogVisible(false) },
      containerColor = WaDarkSurface,
      titleContentColor = WaTextPrimary,
      title = {
        Text("Ukuran Tampilan (Zoom)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "Sesuaikan skala tampilan agar kode QR atau teks pesan nyaman dibaca di layar HP:",
            fontSize = 13.sp,
            color = WaTextSecondary
          )
          Spacer(modifier = Modifier.height(4.dp))
          zoomOptions.forEach { level ->
            val isSelected = uiState.zoomLevel == level
            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                  viewModel.setZoomLevel(level)
                  webViewInstance?.settings?.textZoom = level
                  viewModel.setZoomDialogVisible(false)
                },
              color = if (isSelected) WaDarkSurfaceHighlight else WaDarkSurfaceVariant
            ) {
              Row(
                modifier = Modifier
                  .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "$level%" + if (level == 100) " (Standar)" else "",
                  color = if (isSelected) WaGreenAccent else WaTextPrimary,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  fontSize = 14.sp
                )
                if (isSelected) {
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = WaGreenAccent,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { viewModel.setZoomDialogVisible(false) }) {
          Text("Tutup", color = WaGreenAccent)
        }
      }
    )
  }

  // 4. Permissions Dialog
  if (uiState.showPermissionDialog) {
    AlertDialog(
      onDismissRequest = { viewModel.setPermissionDialogVisible(false) },
      containerColor = WaDarkSurface,
      titleContentColor = WaTextPrimary,
      title = {
        Text("Izin Notifikasi & Perangkat", fontWeight = FontWeight.Bold, fontSize = 18.sp)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            text = "Untuk pengalaman WhatsApp Web terbaik, aktifkan izin berikut:",
            fontSize = 13.sp,
            color = WaTextSecondary
          )

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Notifications,
              contentDescription = null,
              tint = if (uiState.hasNotificationPermission) WaGreenAccent else Color(0xFFF5A623),
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("Notifikasi Pesan Masuk", color = WaTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
              Text(
                if (uiState.hasNotificationPermission) "Sudah diizinkan" else "Belum diaktifkan",
                color = if (uiState.hasNotificationPermission) WaGreenAccent else WaTextMuted,
                fontSize = 11.sp
              )
            }
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = WaGreenAccent,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("Kamera & Mikrofon", color = WaTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
              Text("Diminta otomatis saat merekam suara atau video", color = WaTextMuted, fontSize = 11.sp)
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.setPermissionDialogVisible(false)
            onRequestAllDevicePermissions()
          },
          colors = ButtonDefaults.buttonColors(containerColor = WaGreenPrimary)
        ) {
          Text("Beri Izin")
        }
      },
      dismissButton = {
        TextButton(onClick = { viewModel.setPermissionDialogVisible(false) }) {
          Text("Tutup", color = WaTextSecondary)
        }
      }
    )
  }

  // Clean up WebView on disposal
  DisposableEffect(Unit) {
    onDispose {
      webViewInstance?.destroy()
      webViewInstance = null
    }
  }
}
