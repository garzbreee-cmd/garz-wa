package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = WaGreenPrimary,
  onPrimary = Color.White,
  primaryContainer = WaGreenDark,
  onPrimaryContainer = WaTextPrimary,
  secondary = WaGreenAccent,
  onSecondary = Color.Black,
  secondaryContainer = WaDarkSurfaceHighlight,
  onSecondaryContainer = WaTextPrimary,
  tertiary = WaBlueAccent,
  onTertiary = Color.White,
  background = WaDarkBackground,
  onBackground = WaTextPrimary,
  surface = WaDarkSurface,
  onSurface = WaTextPrimary,
  surfaceVariant = WaDarkSurfaceVariant,
  onSurfaceVariant = WaTextSecondary,
  outline = WaDivider,
  outlineVariant = WaDarkSurfaceHighlight,
  error = WaError,
  onError = Color.White
)

@Composable
fun GarzWATheme(
  content: @Composable () -> Unit
) {
  // Always use the WhatsApp Dark Green theme as requested by the user brief
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
