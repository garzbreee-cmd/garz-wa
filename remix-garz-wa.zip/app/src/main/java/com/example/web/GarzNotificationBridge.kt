package com.example.web

import android.webkit.JavascriptInterface
import com.example.util.NotificationHelper

class GarzNotificationBridge(
  private val notificationHelper: NotificationHelper,
  private val onNotificationReceived: ((title: String, body: String) -> Unit)? = null
) {
  @JavascriptInterface
  fun postWebNotification(title: String, body: String, tag: String?) {
    notificationHelper.showNotification(title, body, tag)
    onNotificationReceived?.invoke(title, body)
  }
}
