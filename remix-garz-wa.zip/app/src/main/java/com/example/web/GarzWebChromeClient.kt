package com.example.web

import android.net.Uri
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView

class GarzWebChromeClient(
  private val onProgressChanged: (Int) -> Unit,
  private val onOpenFileChooser: (ValueCallback<Array<Uri>>?, FileChooserParams?) -> Boolean,
  private val onMediaPermissionRequest: (PermissionRequest) -> Unit
) : WebChromeClient() {

  override fun onProgressChanged(view: WebView?, newProgress: Int) {
    super.onProgressChanged(view, newProgress)
    onProgressChanged(newProgress)
  }

  override fun onShowFileChooser(
    webView: WebView?,
    filePathCallback: ValueCallback<Array<Uri>>?,
    fileChooserParams: FileChooserParams?
  ): Boolean {
    return onOpenFileChooser(filePathCallback, fileChooserParams)
  }

  override fun onPermissionRequest(request: PermissionRequest?) {
    if (request != null) {
      onMediaPermissionRequest(request)
    } else {
      super.onPermissionRequest(request)
    }
  }

  override fun onGeolocationPermissionsShowPrompt(
    origin: String?,
    callback: GeolocationPermissions.Callback?
  ) {
    callback?.invoke(origin, true, false)
  }
}
