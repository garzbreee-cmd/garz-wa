package com.example.web

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.util.WebConstants

class GarzWebViewClient(
  private val context: Context,
  private val onPageLoadingStateChanged: (isLoading: Boolean, url: String?) -> Unit,
  private val onPageError: (hasError: Boolean, errorMessage: String?) -> Unit,
  private val onNavigationStateChanged: (canGoBack: Boolean, canGoForward: Boolean) -> Unit
) : WebViewClient() {

  override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
    super.onPageStarted(view, url, favicon)
    onPageLoadingStateChanged(true, url)
    onPageError(false, null)
    view?.let {
      onNavigationStateChanged(it.canGoBack(), it.canGoForward())
      // Inject early so notification permissions are ready
      it.evaluateJavascript(WebConstants.NOTIFICATION_INJECTION_SCRIPT, null)
    }
  }

  override fun onPageFinished(view: WebView?, url: String?) {
    super.onPageFinished(view, url)
    onPageLoadingStateChanged(false, url)
    view?.let { webView ->
      onNavigationStateChanged(webView.canGoBack(), webView.canGoForward())
      // Ensure persistent cookies are committed to disk
      CookieManager.getInstance().flush()
      // Inject notification bridge script
      webView.evaluateJavascript(WebConstants.NOTIFICATION_INJECTION_SCRIPT, null)
    }
  }

  override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
    val uri = request?.url ?: return false
    val scheme = uri.scheme?.lowercase() ?: ""
    val host = uri.host?.lowercase() ?: ""

    // Allow WhatsApp Web to proceed in WebView
    if (host.contains("whatsapp.com") || host.contains("whatsapp.net")) {
      return false
    }

    // Open external schemes or external web links in external browser / appropriate apps
    return try {
      val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(intent)
      true
    } catch (e: Exception) {
      false
    }
  }

  override fun onReceivedError(
    view: WebView?,
    request: WebResourceRequest?,
    error: WebResourceError?
  ) {
    super.onReceivedError(view, request, error)
    if (request?.isForMainFrame == true) {
      val errorDescription = error?.description?.toString() ?: "Gagal memuat WhatsApp Web"
      onPageError(true, errorDescription)
    }
  }
}
