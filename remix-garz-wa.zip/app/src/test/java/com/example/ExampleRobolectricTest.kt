package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ui.GarzWaViewModel
import com.example.util.WebConstants
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Garz WA", appName)
  }

  @Test
  fun `verify web constants and user agent`() {
    assertTrue(WebConstants.WHATSAPP_WEB_URL.contains("web.whatsapp.com"))
    assertTrue(WebConstants.DESKTOP_USER_AGENT.contains("Windows NT 10.0"))
    assertTrue(WebConstants.DESKTOP_USER_AGENT.contains("Chrome"))
  }

  @Test
  fun `verify view model state transitions`() {
    val viewModel = GarzWaViewModel()
    
    // Initial state
    assertEquals(100, viewModel.uiState.value.zoomLevel)
    assertTrue(viewModel.uiState.value.isLoading)

    // Update progress
    viewModel.updateLoadingProgress(50)
    assertEquals(50, viewModel.uiState.value.loadingProgress)
    assertTrue(viewModel.uiState.value.isLoading)

    // Complete loading
    viewModel.updateLoadingProgress(100)
    assertFalse(viewModel.uiState.value.isLoading)

    // Change zoom level
    viewModel.setZoomLevel(125)
    assertEquals(125, viewModel.uiState.value.zoomLevel)

    // Navigation updates
    viewModel.updateNavigationState(canGoBack = true, canGoForward = false)
    assertTrue(viewModel.uiState.value.canGoBack)
    assertFalse(viewModel.uiState.value.canGoForward)
  }
}
